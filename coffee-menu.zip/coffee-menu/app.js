(() => {
  'use strict';

  const BY_ID = Object.fromEntries(ITEMS.map(i => [i.id, i]));
  const STORAGE_KEY = 'zerno-order-v1';

  const state = {
    cat: 'all',
    order: loadOrder(),   // { 'id:sizeIndex': qty }
    dineIn: 'hall',       // 'hall' | 'togo'
    when: 'asap',         // 'asap' | минуты
    stack: [],            // открытые окна: { type: 'product', id, size } | { type: 'order' }
  };

  const $ = sel => document.querySelector(sel);
  const overlay = $('#overlay');
  const sheet = $('#sheet');
  const cartBar = $('#cartBar');

  // ───────── helpers

  const fmt = n => Math.round(n).toLocaleString('ru-RU') + ' ₸';
  const keyOf = (id, size = 0) => `${id}:${size}`;
  const parseKey = key => {
    const [id, size] = key.split(':');
    return { item: BY_ID[id], size: Number(size) || 0 };
  };
  const priceOf = (item, size = 0) => item.sizes ? item.sizes[size].price : item.price;
  const minPrice = item => item.sizes ? Math.min(...item.sizes.map(s => s.price)) : item.price;
  const colors = item => PALETTE[item.cat] || PALETTE.coffee;
  const qtyOf = key => state.order[key] || 0;

  function loadOrder() {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || {}; } catch { return {}; }
  }
  function saveOrder() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state.order)); } catch { /* приватный режим */ }
  }

  function orderLines() {
    return Object.entries(state.order)
      .filter(([key, q]) => q > 0 && parseKey(key).item)
      .map(([key, qty]) => ({ key, qty, ...parseKey(key) }));
  }
  const orderCount = () => orderLines().reduce((s, l) => s + l.qty, 0);
  const orderTotal = () => orderLines().reduce((s, l) => s + priceOf(l.item, l.size) * l.qty, 0);

  function plural(n, one, few, many) {
    const m10 = n % 10, m100 = n % 100;
    if (m10 === 1 && m100 !== 11) return one;
    if (m10 >= 2 && m10 <= 4 && (m100 < 10 || m100 >= 20)) return few;
    return many;
  }

  // ───────── шаблоны

  function pic(item, cls = '') {
    const [c1, c2] = colors(item);
    const multi = [...item.emoji].length > 1 ? ' multi' : '';
    return `<div class="pic ${cls}${multi}" style="--c1:${c1};--c2:${c2}"><span>${item.emoji}</span></div>`;
  }

  // Кнопка «В заказ» или счётчик. Обновляется через updateSlots() без перерисовки карточек.
  function control(key, variant) {
    const q = qtyOf(key);
    const cls = variant === 'card' ? '' : variant; // «card» — уже класс карточки, на кнопку его не вешаем
    const { item, size } = parseKey(key);
    if (!q) {
      const label = variant === 'big'
        ? `Добавить в заказ <span class="btn-sub">${fmt(priceOf(item, size))}</span>`
        : `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>В заказ`;
      return `<button class="btn-add ${cls}" type="button" data-add="${key}">${label}</button>`;
    }
    return `
      <div class="stepper ${cls}">
        <button type="button" data-dec="${key}" aria-label="Убрать одну">−</button>
        <span>${variant === 'big' ? `${q} в заказе` : q}</span>
        <button type="button" data-inc="${key}" aria-label="Добавить ещё">+</button>
      </div>`;
  }
  const slot = (key, variant) => `<div class="slot" data-slot="${key}" data-variant="${variant}">${control(key, variant)}</div>`;

  function card(item) {
    const priceLabel = item.sizes ? `от ${fmt(minPrice(item))}` : fmt(item.price);
    return `
      <article class="card" data-open="${item.id}" tabindex="0" aria-label="${item.name}">
        <div class="card-pic">
          ${pic(item)}
          ${item.badge ? `<span class="badge">${item.badge}</span>` : ''}
        </div>
        <div class="card-body">
          <h3 class="card-title">${item.name}</h3>
          <p class="card-short">${item.short}</p>
          <div class="card-price">
            <b>${priceLabel}</b>
            ${item.oldPrice ? `<s>${fmt(item.oldPrice)}</s>` : ''}
          </div>
          ${slot(keyOf(item.id), 'card')}
        </div>
      </article>`;
  }

  // ───────── главный экран

  function renderToday() {
    const d = new Date();
    $('#todayDate').textContent = d.toLocaleDateString('ru-RU', { weekday: 'long', day: 'numeric', month: 'long' });

    $('#specials').innerHTML = SPECIALS.map(({ label, id }) => {
      const item = BY_ID[id];
      const priceLabel = item.sizes ? `от ${fmt(minPrice(item))}` : fmt(item.price);
      const discount = item.oldPrice ? Math.round((1 - item.price / item.oldPrice) * 100) : 0;
      return `
        <article class="special" data-open="${id}" tabindex="0">
          <div class="special-pic">
            ${pic(item)}
            ${discount ? `<span class="badge hot">−${discount}%</span>` : ''}
          </div>
          <div class="special-body">
            <span class="special-label">${label}</span>
            <h3>${item.name}</h3>
            <p>${item.short}</p>
            <div class="special-foot">
              <div class="card-price">
                <b>${priceLabel}</b>
                ${item.oldPrice ? `<s>${fmt(item.oldPrice)}</s>` : ''}
              </div>
              ${slot(keyOf(id), 'card')}
            </div>
          </div>
        </article>`;
    }).join('');
  }

  function renderTabs() {
    $('#tabs').innerHTML = CATEGORIES.map(c => `
      <button class="tab ${c.id === state.cat ? 'active' : ''}" type="button" role="tab"
              aria-selected="${c.id === state.cat}" data-cat="${c.id}">
        <span class="tab-emoji">${c.emoji}</span>${c.name}
      </button>`).join('');
    const tabs = $('#tabs');
    const active = tabs.querySelector('.active');
    if (active) {
      tabs.scrollTo({ left: active.offsetLeft - (tabs.clientWidth - active.offsetWidth) / 2, behavior: 'smooth' });
    }
  }

  function renderMenu() {
    const groups = state.cat === 'all'
      ? CATEGORIES.filter(c => c.id !== 'all')
      : CATEGORIES.filter(c => c.id === state.cat);

    $('#menu').innerHTML = groups.map(c => {
      const items = ITEMS.filter(i => i.cat === c.id);
      return `
        <div class="group">
          <h2 class="group-title">${c.name} <span>${items.length}</span></h2>
          <div class="grid">${items.map(card).join('')}</div>
        </div>`;
    }).join('');
  }

  function renderCartBar() {
    const count = orderCount();
    cartBar.hidden = count === 0;
    if (!count) return;
    cartBar.innerHTML = `
      <span class="cart-bar-left">
        <span class="cart-bar-count">${count}</span>
        Перейти к заказу
      </span>
      <b>${fmt(orderTotal())}</b>`;
  }

  function updateSlots() {
    document.querySelectorAll('.slot').forEach(el => {
      el.innerHTML = control(el.dataset.slot, el.dataset.variant);
    });
  }

  // ───────── рекомендации: к напиткам — сладкое, к еде — напитки

  function recommendationsFor(item) {
    let cats;
    if (item.cat === 'cold') cats = ['desserts', 'bakery', 'snacks'];
    else if (DRINK_CATS.includes(item.cat) || item.cat === 'combo') cats = ['desserts', 'bakery'];
    else if (item.cat === 'desserts' || item.cat === 'bakery') cats = ['coffee', 'tea'];
    else cats = ['coffee', 'tea', 'cold'];

    // стабильное «случайное» перемешивание, чтобы у каждой позиции был свой набор
    const hash = s => [...s].reduce((h, ch) => (h * 31 + ch.charCodeAt(0)) >>> 0, 7);
    return ITEMS
      .filter(i => cats.includes(i.cat) && i.id !== item.id)
      .sort((a, b) => hash(item.id + a.id) - hash(item.id + b.id))
      .slice(0, 8);
  }

  // ───────── окно позиции

  function productView(entry) {
    const item = BY_ID[entry.id];
    const size = entry.size || 0;
    const sz = item.sizes ? item.sizes[size] : null;
    const k = sz ? sz.k : 1;
    const r = v => (v * k >= 10 ? Math.round(v * k) : Math.round(v * k * 10) / 10).toString().replace('.', ',');
    const amount = sz ? sz.amount : item.weight;
    const isDrink = DRINK_CATS.includes(item.cat);
    const recs = recommendationsFor(item);
    const recTitle = isDrink || item.cat === 'combo' ? 'К этому напитку возьмите' : 'К этому подойдёт';

    return `
      <div class="pm">
        <div class="pm-hero">
          ${pic(item, 'xl')}
          ${item.badge ? `<span class="badge big">${item.badge}</span>` : ''}
        </div>

        <div class="pm-body">
          <h2 class="pm-title">${item.name}</h2>
          <div class="pm-meta">
            <span>${amount}</span>
            <span>~${item.prep} мин</span>
            <span>${r(item.kcal)} ккал</span>
          </div>

          ${item.sizes ? `
            <div class="sizes" role="radiogroup" aria-label="Размер">
              ${item.sizes.map((s, i) => `
                <button type="button" class="size ${i === size ? 'active' : ''}" data-size="${i}" role="radio" aria-checked="${i === size}">
                  <b>${s.label}</b><small>${s.amount}</small>
                </button>`).join('')}
            </div>` : ''}

          <div class="pm-buy">
            <div class="pm-price">
              <b>${fmt(priceOf(item, size))}</b>
              ${item.oldPrice ? `<s>${fmt(item.oldPrice)}</s>` : ''}
            </div>
            ${slot(keyOf(item.id, size), 'big')}
          </div>

          <p class="pm-desc">${item.desc}</p>

          <h3 class="pm-h">Пищевая ценность <small>на ${amount}</small></h3>
          <div class="nutri">
            <div><b>${r(item.kcal)}</b><small>ккал</small></div>
            <div><b>${r(item.p)}</b><small>белки, г</small></div>
            <div><b>${r(item.f)}</b><small>жиры, г</small></div>
            <div><b>${r(item.c)}</b><small>углеводы, г</small></div>
          </div>

          <h3 class="pm-h">Состав</h3>
          <div class="chips">${item.ing.map(x => `<span>${x}</span>`).join('')}</div>

          <dl class="facts">
            <div><dt>${isDrink ? 'Объём' : 'Вес'}</dt><dd>${amount}</dd></div>
            ${item.sizes ? `<div><dt>Размеры</dt><dd>${item.sizes.map(s => s.amount).join(' / ')}</dd></div>` : ''}
            <div><dt>Время приготовления</dt><dd>~${item.prep} мин</dd></div>
          </dl>

          <h3 class="pm-h rec-title">${recTitle}</h3>
          <div class="rec-row">${recs.map(card).join('')}</div>
        </div>
      </div>`;
  }

  // ───────── окно заказа

  function estimateMinutes() {
    const lines = orderLines();
    if (!lines.length) return 0;
    const maxPrep = Math.max(...lines.map(l => l.item.prep));
    const qty = lines.reduce((s, l) => s + l.qty, 0);
    const raw = maxPrep + Math.min(15, (qty - 1) * 2);
    return Math.max(5, Math.ceil(raw / 5) * 5);
  }

  const clock = mins => new Date(Date.now() + mins * 60000)
    .toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });

  function timeOptions() {
    const est = estimateMinutes();
    const opts = [{ id: 'asap', title: 'Побыстрее', sub: `~${est} мин · к ${clock(est)}` }];
    [[30, 'Через 30 мин'], [60, 'Через 1 час'], [90, 'Через 1,5 часа'], [120, 'Через 2 часа']]
      .forEach(([m, title]) => {
        if (m >= est + 5) opts.push({ id: String(m), title, sub: `к ${clock(m)}` });
      });
    return opts;
  }

  function orderView() {
    const lines = orderLines();
    if (!lines.length) {
      return `
        <div class="om">
          <h2 class="om-title">Ваш заказ</h2>
          <div class="empty">
            <div class="empty-emoji">🧾</div>
            <p>В заказе пока пусто</p>
            <small>Добавьте что-нибудь вкусное из меню</small>
            <button class="btn-primary" type="button" data-close>Вернуться в меню</button>
          </div>
        </div>`;
    }

    const opts = timeOptions();
    if (!opts.some(o => o.id === state.when)) state.when = 'asap';
    const count = orderCount();

    return `
      <div class="om">
        <div class="om-head">
          <h2 class="om-title">Ваш заказ</h2>
          <button class="link" type="button" data-clear>Очистить</button>
        </div>

        <ul class="lines">
          ${lines.map(l => {
            const s = l.item.sizes ? l.item.sizes[l.size] : null;
            return `
              <li class="line">
                <div class="line-pic" data-open="${l.item.id}" data-open-size="${l.size}">${pic(l.item)}</div>
                <div class="line-info" data-open="${l.item.id}" data-open-size="${l.size}">
                  <b>${l.item.name}</b>
                  <small>${s ? `${s.label} · ${s.amount}` : l.item.weight}</small>
                  <small>${fmt(priceOf(l.item, l.size))} × ${l.qty}</small>
                </div>
                <div class="line-right">
                  <b>${fmt(priceOf(l.item, l.size) * l.qty)}</b>
                  ${control(l.key, 'mini')}
                </div>
              </li>`;
          }).join('')}
        </ul>

        <h3 class="pm-h">Где будете есть?</h3>
        <div class="segmented">
          <button type="button" class="${state.dineIn === 'hall' ? 'active' : ''}" data-dine="hall">🪑 В зале</button>
          <button type="button" class="${state.dineIn === 'togo' ? 'active' : ''}" data-dine="togo">🛍️ С собой</button>
        </div>

        <h3 class="pm-h">Когда приготовить?</h3>
        <div class="times">
          ${opts.map(o => `
            <button type="button" class="time ${o.id === state.when ? 'active' : ''}" data-when="${o.id}">
              <b>${o.title}</b><small>${o.sub}</small>
            </button>`).join('')}
        </div>
        <p class="hint">Время рассчитано по самой долгой позиции в заказе и загрузке кухни.</p>

        <div class="summary">
          <div><span>${count} ${plural(count, 'позиция', 'позиции', 'позиций')}</span><span>${fmt(orderTotal())}</span></div>
          <div class="total"><span>Итого</span><span>${fmt(orderTotal())}</span></div>
        </div>

        <div class="pay-wrap">
          <button class="btn-primary pay" type="button">Оплатить · ${fmt(orderTotal())}</button>
        </div>
      </div>`;
  }

  // ───────── модальные окна (со стеком и кнопкой «Назад» браузера)

  function renderModal(resetScroll) {
    const top = state.stack[state.stack.length - 1];
    if (!top) {
      overlay.classList.remove('open');
      document.body.classList.remove('locked');
      setTimeout(() => { if (!state.stack.length) { overlay.hidden = true; sheet.innerHTML = ''; } }, 250);
      return;
    }

    const scroller = sheet.querySelector('.sheet-scroll');
    const prevScroll = scroller && !resetScroll ? scroller.scrollTop : 0;
    const canBack = state.stack.length > 1;

    sheet.className = `sheet ${top.type}`;
    sheet.setAttribute('aria-label', top.type === 'order' ? 'Ваш заказ' : BY_ID[top.id].name);
    sheet.innerHTML = `
      <div class="sheet-controls">
        ${canBack ? `<button class="round-btn" type="button" data-back aria-label="Назад">
          <svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7"/></svg></button>` : '<span></span>'}
        <button class="round-btn" type="button" data-close aria-label="Закрыть">
          <svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg></button>
      </div>
      <div class="sheet-scroll">${top.type === 'order' ? orderView() : productView(top)}</div>`;

    sheet.querySelector('.sheet-scroll').scrollTop = prevScroll;
    if (resetScroll) {
      sheet.classList.remove('swap');
      void sheet.offsetWidth;
      sheet.classList.add('swap');
    }

    if (overlay.hidden) {
      overlay.hidden = false;
      requestAnimationFrame(() => overlay.classList.add('open'));
    } else {
      overlay.classList.add('open');
    }
    document.body.classList.add('locked');
  }

  function pushModal(entry) {
    state.stack.push(entry);
    history.pushState({ depth: state.stack.length }, '');
    renderModal(true);
  }

  function closeAll() {
    if (state.stack.length) history.go(-state.stack.length);
  }

  window.addEventListener('popstate', e => {
    const depth = (e.state && e.state.depth) || 0;
    if (depth < state.stack.length) {
      state.stack.length = depth;
      renderModal(true);
    }
  });

  // ───────── изменение заказа

  function changeQty(key, delta) {
    const q = Math.max(0, qtyOf(key) + delta);
    if (q) state.order[key] = q; else delete state.order[key];
    saveOrder();
    updateSlots();
    renderCartBar();
    if (delta > 0) {
      cartBar.classList.remove('bump');
      void cartBar.offsetWidth;
      cartBar.classList.add('bump');
    }
    const top = state.stack[state.stack.length - 1];
    if (top && top.type === 'order') renderModal(false);
  }

  // ───────── события

  document.addEventListener('click', e => {
    if (e.target === overlay) { closeAll(); return; }

    const t = e.target.closest(
      '[data-add],[data-inc],[data-dec],[data-open],[data-cat],[data-size],[data-close],[data-back],[data-order],[data-clear],[data-dine],[data-when]'
    );
    if (!t) return;
    const d = t.dataset;

    if (d.add) changeQty(d.add, 1);
    else if (d.inc) changeQty(d.inc, 1);
    else if (d.dec) changeQty(d.dec, -1);
    else if (d.open) pushModal({ type: 'product', id: d.open, size: Number(d.openSize) || 0 });
    else if (d.cat) {
      state.cat = d.cat;
      renderTabs();
      renderMenu();
      const nav = $('#tabsWrap');
      const top = $('#menu').getBoundingClientRect().top + window.scrollY - nav.offsetHeight - 8;
      if (window.scrollY > top) window.scrollTo({ top, behavior: 'smooth' });
    }
    else if (d.size !== undefined) {
      const top = state.stack[state.stack.length - 1];
      top.size = Number(d.size);
      renderModal(false);
    }
    else if (d.close !== undefined) closeAll();
    else if (d.back !== undefined) history.back();
    else if (d.order !== undefined) pushModal({ type: 'order' });
    else if (d.clear !== undefined) {
      state.order = {};
      saveOrder();
      updateSlots();
      renderCartBar();
      renderModal(false);
    }
    else if (d.dine) { state.dineIn = d.dine; renderModal(false); }
    else if (d.when) { state.when = d.when; renderModal(false); }
  });

  // карточки открываются и с клавиатуры
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && state.stack.length) { closeAll(); return; }
    if ((e.key === 'Enter' || e.key === ' ') && e.target.matches('[data-open][tabindex]')) {
      e.preventDefault();
      e.target.click();
    }
  });

  // тень у ленты разделов, когда она прилипла к верху
  const tabsWrap = $('#tabsWrap');
  new IntersectionObserver(([en]) => tabsWrap.classList.toggle('stuck', en.intersectionRatio < 1),
    { threshold: [1], rootMargin: '-1px 0px 0px 0px' }).observe(tabsWrap);

  // если страницу обновили с открытым окном — сбрасываем состояние истории
  if (history.state && history.state.depth) history.replaceState(null, '');

  renderToday();
  renderTabs();
  renderMenu();
  renderCartBar();
})();
